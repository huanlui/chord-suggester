const Constants = {
    NumberOfNotes: 12,
    SequenceLength: 20,
    SuggestedChordNumber: 7
}

export default Constants;